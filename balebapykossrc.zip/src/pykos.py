import os


def scan_files():
    files = os.listdir()
    print("Scanning files...")
    for file in files:
        print(file)


def execute_file(file_name):
    print(f"Executing file: {file_name}")
    os.system(file_name)


def main():
    print("Welcome to the File Scanner App!")
    while True:
        print("\nMenu:")
        print("1. Scan files")
        print("2. Execute file")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            scan_files()
        elif choice == "2":
            file_name = input("Enter the file name: ")
            execute_file(file_name)
        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
