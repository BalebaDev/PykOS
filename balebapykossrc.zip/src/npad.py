import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter import font

class NotepadApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Notepad App")
        self.root.geometry("800x600")

        self.text_area = tk.Text(self.root, font=("Arial", 12))
        self.text_area.pack(fill=tk.BOTH, expand=True)

        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)

        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save", command=self.save_file)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.root.quit)

        self.edit_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Edit", menu=self.edit_menu)
        self.edit_menu.add_command(label="Change Text Size", command=self.change_text_size)

        self.about_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="About", menu=self.about_menu)
        self.about_menu.add_command(label="Author", command=self.show_author_info)
        self.about_menu.add_command(label="PykDOS", command=self.show_pykdos_info)

    def open_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if file_path:
            with open(file_path, "r") as file:
                self.text_area.delete("1.0", tk.END)
                self.text_area.insert(tk.END, file.read())

    def save_file(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if file_path:
            with open(file_path, "w") as file:
                file.write(self.text_area.get("1.0", tk.END))

    def change_text_size(self):
        size_window = tk.Toplevel(self.root)
        size_window.title("Change Text Size")
        size_window.geometry("300x100")

        size_slider = tk.Scale(size_window, from_=8, to=72, orient=tk.HORIZONTAL)
        size_slider.pack(pady=20)

        def update_text_size():
            selected_size = size_slider.get()
            current_font = font.Font(font=self.text_area["font"])
            current_font.configure(size=selected_size)
            self.text_area.configure(font=current_font)

        apply_button = tk.Button(size_window, text="Apply", command=update_text_size)
        apply_button.pack()

    def show_author_info(self):
        messagebox.showinfo("Author", "Author: Chedrillo")

    def show_pykdos_info(self):
        messagebox.showinfo("PykDOS", "PykDOS is a lightweight operating system, written in Python.")

root = tk.Tk()
notepad_app = NotepadApp(root)
root.mainloop()
