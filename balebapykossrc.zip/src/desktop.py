import os
import tkinter as tk


# Function to scan files in the current directory
def scan_files():
    # Get the current directory
    current_dir = os.getcwd()

    # Create a list to store the scanned files
    scanned_files = []

    # Scan all files in the current directory
    for file in os.listdir(current_dir):
        # Check if the file is not a directory
        if os.path.isfile(os.path.join(current_dir, file)):
            # Add the file to the scanned_files list
            scanned_files.append(file)

    # Create a GUI window
    window = tk.Tk()

    # Set the background image
    background_image = tk.PhotoImage(file="background.jpg")
    background_label = tk.Label(window, image=background_image)
    background_label.pack()

    # Create a label to display the scanned files
    files_label = tk.Label(window, text="\n".join(scanned_files))
    files_label.pack()

    # Run the GUI window
    window.mainloop()


# Call the scan_files function
scan_files()
