import tkinter as tk
from tkinter import filedialog
import cv2


def play_video():
    # Open file dialog to select video file
    file_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])

    # Check if a file was selected
    if file_path:
        # Create a video capture object
        cap = cv2.VideoCapture(file_path)

        # Get the video resolution
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # Create a resizable window
        root = tk.Tk()
        root.geometry(f"{width}x{height}")
        root.configure(bg="yellow")

        # Create a canvas to display the video frames
        canvas = tk.Canvas(root, width=width, height=height)
        canvas.pack()

        while True:
            # Read a frame from the video
            ret, frame = cap.read()

            # Check if frame was read successfully
            if not ret:
                break

            # Convert the frame to RGB format
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Create an image from the frame
            img = Image.fromarray(frame_rgb)

            # Resize the image to fit the canvas
            img = img.resize((width, height), Image.ANTIALIAS)

            # Convert the image to Tkinter PhotoImage
            photo = ImageTk.PhotoImage(img)

            # Display the image on the canvas
            canvas.create_image(0, 0, anchor=tk.NW, image=photo)

            # Update the window
            root.update()

        # Release the video capture object
        cap.release()

        # Close the window when video playback is finished
        root.destroy()


# Create a button to open the video file
button = tk.Button(text="Open Video", command=play_video)
button.pack()

# Create the main window
window = tk.Tk()
window.mainloop()
