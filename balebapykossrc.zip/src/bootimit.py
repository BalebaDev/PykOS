import time
import os

def bootimit():
    time.sleep(5)
    print(r'''
    MMMMMMMMMMMWXOxoc:;,,,;;:coxOKNMMMMMMMMM   
    MMMMMMWKkoc;'.   ';:ccc::;;;;',:lxKWMMMM
    MMMNOl,',:ol.  .oNMMWMMMMMWKo.   .';dKWM
    MXd,.,oONWO'   ,0MMMMMWN0xc'    .o0o..xW
    K; 'kNMMWk.     ;dxdol;'.       lNMWx..k
    l '0MMMWk.                     lNMMWx..x
    d '0MMWO.       .;codxko.    .lNMMNd. cX
    No.,xX0,     .cxXWMMMMMN:   .dNXOo'.,kNM
    MW0l,,.    'dKWMMMMMMMWk.   'c;'.,lONMMM
    MMMMNOoc,..'::ccllccc:,. ...,:lxKNWMMMMM
    MMMMMMMMWKOxoc:;,,;;;:codk0XWMMMMMWMMMMM


     _____ _____ __    _____ _____ _____                         
    | __  |  _  |  |  |   __| __  |  _  |                        
    | __ -|     |  |__|   __| __ -|     |                        
    |_____|__|__|_____|_____|_____|__|__|                        


     _____ _____ _____ _____ _____ _____ _____ _____ ____  _____ 
    |     |   __|   __|  _  |_   _| __  |   __|   | |    \|   __|
    | | | |   __|  |  |     | | | |    -|   __| | | |  |  |__   |
    |_|_|_|_____|_____|__|__| |_| |__|__|_____|_|___|____/|_____|


    PONONOS MODULAR BIOS V. 1.0
    (C) Baleba NORTH 2004-2025
    (C) Chedrillo BOREALIS 2009-20XX
    Baleba (R) BLMB-1061WB Motherboard

    Memory: 4096wb.. OK
    Baleba(R) Maxino Radial 2 A9592 x2... OK

    Press F8 for boot menu.....
    Press DEL for Baleba (R) Setup Utility.....

    SATA1 - Detected BALEBA Chechi-Chechi 1024mb WBB DRIVE
    SATA2 - CD-ROM Detected

    CD-ROM is empty.

    Detecting USB devices......... 2 devices... OK

    Booting from WBB drive
    Starting PykOS........''')

def launcher():
    file_name = "pykos.exe"
    file_path = os.path.join(os.path.dirname(__file__), file_name)

    if os.path.isfile(file_path):
        os.system(file_path)
    else:
        print(f"File '{file_name}' does not exist in the current directory.")

bootimit()
launcher()
